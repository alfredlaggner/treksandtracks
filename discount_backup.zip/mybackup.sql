#
# TABLE STRUCTURE FOR: discount
#

DROP TABLE IF EXISTS discount;

CREATE TABLE `discount` (
  `discount_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  `promo_code` varchar(255) COLLATE utf8_bin NOT NULL,
  `amount` decimal(9,2) NOT NULL,
  `amount_type` tinytext COLLATE utf8_bin NOT NULL,
  `type` tinytext COLLATE utf8_bin NOT NULL,
  `weekdays` varchar(7) COLLATE utf8_bin NOT NULL,
  `is_automatic_apply` tinyint(1) NOT NULL,
  `res_party_size_from` int(11) NOT NULL,
  `res_party_size_to` int(11) NOT NULL,
  `exp_date` date NOT NULL,
  `departure_date_start` date NOT NULL,
  `departure_date_end` date NOT NULL,
  `auto_join_group` int(11) NOT NULL,
  `is_rule_active` tinyint(1) NOT NULL,
  `is_single_use` tinyint(1) NOT NULL,
  `is_global_discount` tinyint(1) NOT NULL,
  `is_imported` tinyint(1) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`discount_id`),
  UNIQUE KEY `promo_code` (`promo_code`(30))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

#
# TABLE STRUCTURE FOR: discount_to_activity
#

DROP TABLE IF EXISTS discount_to_activity;

CREATE TABLE `discount_to_activity` (
  `discount_id` int(11) NOT NULL,
  `activity_id` int(11) NOT NULL,
  UNIQUE KEY `discount_id` (`discount_id`,`activity_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

