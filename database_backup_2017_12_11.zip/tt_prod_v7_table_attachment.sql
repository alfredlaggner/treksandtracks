
-- --------------------------------------------------------

--
-- Table structure for table `attachment`
--

DROP TABLE IF EXISTS `attachment`;
CREATE TABLE `attachment` (
  `attachment_id` int(11) NOT NULL,
  `attachment_name` varchar(50) NOT NULL,
  `file_name` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attachment`
--

INSERT INTO `attachment` (`attachment_id`, `attachment_name`, `file_name`) VALUES
(7, 'Backpacking Gear List Itinary Ojai ', 'Backpacking_Gear_list_and_itinerary_-_Ojai.docx'),
(9, 'Backpacking Registration Form Ojai', 'Backpacking_Registration_Form_-_Ojai.docx'),
(10, 'Liability Waiver Back Packing', 'liability waiver back packing.pdf'),
(11, 'Backpacking Gear List Castle Rock State Park', 'Backpacking Gear list and itinerary CRSP.docx'),
(12, 'Rock Climbing Liability Waiver Waiver  Castle Rock', 'liability waiver  cock climbing castle rock park.pdf'),
(13, '', 'Directions to Castle Rock State Park.docx'),
(14, 'Wilderness Survival Gear list', 'Wilderness Survival Class Gear list.docx'),
(15, 'Backpacking Gear List', 'Backpacking General Gear list.docx'),
(16, 'Rock Climbing Liability', 'Rock climbing liability form.pdf');
