
-- --------------------------------------------------------

--
-- Table structure for table `home_slider`
--

DROP TABLE IF EXISTS `home_slider`;
CREATE TABLE `home_slider` (
  `home_slider_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `slogan` varchar(20) COLLATE utf8_bin NOT NULL,
  `order` int(11) NOT NULL,
  `link` varchar(255) COLLATE utf8_bin NOT NULL,
  `description_short` text COLLATE utf8_bin NOT NULL,
  `region_id` int(11) NOT NULL,
  `is_featured` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `home_slider`
--

INSERT INTO `home_slider` (`home_slider_id`, `name`, `slogan`, `order`, `link`, `description_short`, `region_id`, `is_featured`, `is_active`, `updated`, `updated_by`) VALUES
(12, 'Treks and Tracks', '', 1, 'menu_pages/about_us', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>We offer outdoor education classes and expeditions. It is our mission to create opportunities for people to enjoy the wild places on earth.&nbsp;</p>\n</body>\n</html>', 1, 1, 1, '2012-08-17 05:23:20', 0),
(7, 'Treks and Tracks crew visits Patagonia on Horseback', '', 6, '/blogs/?p=1237', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>Check out our video series of our 3 month expedition to Chilean Patagonia, where we rode into the wilderness on horseback and put up first ascent climbs on Granite Domes.</p>\n</body>\n</html>', 1, 1, 1, '2012-07-23 21:11:04', 0),
(8, 'Experience rock climbing with Treks and Tracks', '', 3, 'blogs/?p=1244', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>Experience rock climbing with Treks and Tracks. Certified guides take you up vertical rock cliffs, and it\'s fun! Check out the short video.</p>\n</body>\n</html>', 1, 1, 1, '2012-07-23 21:28:33', 0),
(9, 'Summer Kid', '', 5, 'tt2/product/42', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>Kid\'s love rock climbing! Our 1, 2 and 3 day camps offer students an incredible experience of climbing vertical rock in the outdoors. Join us for an unforgettable camp.</p>\n</body>\n</html>', 1, 1, 1, '2012-08-17 05:24:58', 0),
(11, 'Certified Guides', '', 2, 'menu_pages/guides', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>Treks and Tracks\' guides operate under the highest industry standards.</p>\n</body>\n</html>', 1, 1, 1, '2012-07-02 02:18:10', 0);
