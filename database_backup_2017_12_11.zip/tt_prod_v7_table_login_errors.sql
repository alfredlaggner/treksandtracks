
-- --------------------------------------------------------

--
-- Table structure for table `login_errors`
--

DROP TABLE IF EXISTS `login_errors`;
CREATE TABLE `login_errors` (
  `ai` int(10) UNSIGNED NOT NULL,
  `username_or_email` varchar(255) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `login_errors`
--

INSERT INTO `login_errors` (`ai`, `username_or_email`, `ip_address`, `time`) VALUES
(80, 'rasdaddy831@gmail.com', '174.214.10.239', '2017-10-16 15:45:57'),
(79, 'rasdaddy831@gmail.com', '174.214.10.239', '2017-10-16 15:43:51');
