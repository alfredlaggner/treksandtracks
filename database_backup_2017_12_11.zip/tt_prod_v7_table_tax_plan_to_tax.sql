
-- --------------------------------------------------------

--
-- Table structure for table `tax_plan_to_tax`
--

DROP TABLE IF EXISTS `tax_plan_to_tax`;
CREATE TABLE `tax_plan_to_tax` (
  `tax_plan_id` int(11) NOT NULL,
  `tax_id` int(11) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tax_plan_to_tax`
--

INSERT INTO `tax_plan_to_tax` (`tax_plan_id`, `tax_id`, `updated`, `updated_by`) VALUES
(6, 7, '0000-00-00 00:00:00', 0),
(2, 0, '0000-00-00 00:00:00', 0),
(2, 3, '0000-00-00 00:00:00', 0),
(5, 1, '0000-00-00 00:00:00', 0),
(5, 3, '0000-00-00 00:00:00', 0),
(1, 3, '0000-00-00 00:00:00', 0),
(1, 4, '0000-00-00 00:00:00', 0),
(6, 4, '0000-00-00 00:00:00', 0),
(1, 5, '0000-00-00 00:00:00', 0);
