
-- --------------------------------------------------------

--
-- Table structure for table `auth_sessions`
--

DROP TABLE IF EXISTS `auth_sessions`;
CREATE TABLE `auth_sessions` (
  `id` varchar(128) NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `login_time` datetime DEFAULT NULL,
  `modified_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` varchar(60) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_sessions`
--

INSERT INTO `auth_sessions` (`id`, `user_id`, `login_time`, `modified_at`, `ip_address`, `user_agent`) VALUES
('l96b5vk0p7nuqk81nrn8re4g1s86dlcg', 2843532195, '2017-10-18 15:19:36', '2017-10-18 15:25:42', '174.214.9.130', 'Safari 604.1 on iOS'),
('53n02bk1ru5a770dqif17gcotd445ote', 2843532195, '2017-10-23 15:22:55', '2017-10-23 15:22:56', '174.214.4.252', 'Safari 604.1 on iOS'),
('t8tsi7haf6cteeqsppfrpob07lpuqmhe', 2843532195, '2017-10-17 00:54:17', '2017-10-17 00:54:17', '174.214.2.138', 'Safari 604.1 on iOS'),
('6fcsslt81pde610hbu327bm8p4efmbdd', 2843532195, '2017-10-16 15:47:02', '2017-10-16 16:22:04', '174.214.10.239', 'Safari 604.1 on iOS'),
('53kpb88o9tfakkn79o749p0rofupod5e', 2843532195, '2017-10-09 16:57:56', '2017-10-09 16:57:56', '174.214.17.15', 'Safari 604.1 on iOS'),
('pl2qaga1o0mfr01jij531h5sknouigqj', 2843532195, '2017-10-11 15:22:07', '2017-10-11 15:40:28', '174.215.2.250', 'Safari 604.1 on iOS'),
('4d6kt5c0lh8te2pt0v84etdj8bmschaf', 2843532195, '2017-10-05 19:34:21', '2017-10-05 20:11:22', '174.214.5.57', 'Safari 604.1 on iOS'),
('lefhlq4vb2l5it64jvhgkgkabpbsltkn', 2843532195, '2017-10-04 17:44:45', '2017-10-04 19:14:22', '174.214.5.57', 'Safari 604.1 on iOS'),
('ikmv6ssjjukkbv2941ti9kmiesovivsl', 2843532195, '2017-10-03 04:21:27', '2017-10-03 04:21:27', '70.213.2.97', 'Safari 604.1 on iOS'),
('mekq1rpmt6269rk2126ggb9huqm6vjd4', 2843532195, '2017-10-02 23:19:16', '2017-10-02 23:30:15', '70.213.2.97', 'Safari 604.1 on iOS'),
('qs5kdq3vjhvheteam0oed0njc0fbsn07', 2843532195, '2017-10-02 16:17:33', '2017-10-02 16:17:33', '70.213.2.97', 'Safari 604.1 on iOS'),
('frqsc69gh9qvtkal3tk4l5hm1a8icnuf', 2843532195, '2017-09-27 18:17:02', '2017-09-27 18:27:47', '70.213.5.24', 'Safari 604.1 on iOS'),
('80bou9qlhmr6c89q5blilp81kbfamg52', 1817101692, '2017-09-26 18:26:58', '2017-09-26 18:26:58', '98.210.243.239', 'Chrome 60.0.3112.113 on Mac OS X'),
('7r0h7t1dm0gasp2q1icgkujttumd7mbn', 2843532195, '2017-09-25 18:47:31', '2017-09-25 19:09:30', '70.213.12.249', 'Safari 604.1 on iOS'),
('cf4v49vjj19n6e5g1osjq1tei4l6o59s', 2843532195, '2017-09-25 16:34:24', '2017-09-25 16:34:24', '70.213.4.18', 'Safari 602.1 on iOS'),
('9917b743vnbjprkrf6c4tbvbcbp1m5nk', 2446419542, '2017-09-20 16:58:27', '2017-09-20 16:58:27', '98.202.194.240', 'Chrome 60.0.3112.113 on Windows 10'),
('9jiuhf8c4qdbj67oifbi7norpum2jng4', 1601689362, '2017-08-17 18:04:45', '2017-08-17 18:04:45', '199.231.240.189', 'Chrome 60.0.3112.90 on Windows 7'),
('o2f3kg4hreqopo74o0tomnti32ae58n5', 1817101692, '2017-09-06 20:22:36', '2017-09-06 20:30:18', '98.210.243.239', 'Chrome 60.0.3112.116 on Android'),
('idangnqa8df2milsbpmtrn366sdj1ar4', 1817101692, '2017-09-06 20:38:16', '2017-09-06 21:47:11', '98.210.243.239', 'Chrome 60.0.3112.113 on Mac OS X'),
('hrv6geofrgmliehr7u1i0ghlcklal47s', 1817101692, '2017-09-07 00:53:07', '2017-09-07 00:53:07', '98.210.243.239', 'Chrome 60.0.3112.113 on Mac OS X'),
('3fj1rddnu4672r3ioiaosbkh4dd5l0hg', 2843532195, '2017-09-07 19:34:02', '2017-09-07 19:34:02', '174.214.14.45', 'Safari 602.1 on iOS'),
('a9vs5gofaaogl1jnap32j6u1903p1g1g', 2843532195, '2017-09-10 15:34:22', '2017-09-10 16:06:08', '70.213.8.139', 'Safari 602.1 on iOS'),
('7n316s7uq2r42v086h08674tihb3sgvr', 2843532195, '2017-09-13 21:57:29', '2017-09-13 21:57:29', '70.213.0.146', 'Safari 602.1 on iOS'),
('9uk4mv3petagqloc30ig8qq98ojvv004', 3876230340, '2017-09-15 18:50:35', '2017-09-15 20:24:57', '66.87.118.15', 'Safari 601.1 on iOS'),
('2aded4qdm5l5niuai4n3af9qd0sdshqn', 1817101692, '2017-09-22 19:28:42', '2017-09-22 20:07:28', '98.210.243.239', 'Chrome 60.0.3112.113 on Mac OS X'),
('ta1ghtvcso80uhu135o25p3p5e4q7qf7', 2843532195, '2017-09-24 19:00:13', '2017-09-24 19:00:13', '70.213.11.61', 'Safari 602.1 on iOS'),
('d468oopn8fqgm8m07lm7ncnkkhedkhnr', 2843532195, '2017-09-20 19:36:59', '2017-09-20 19:36:59', '174.214.14.59', 'Safari 602.1 on iOS');
