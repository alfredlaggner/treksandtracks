
-- --------------------------------------------------------

--
-- Table structure for table `rate_plan`
--

DROP TABLE IF EXISTS `rate_plan`;
CREATE TABLE `rate_plan` (
  `rate_plan_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `description` varchar(255) COLLATE utf8_bin NOT NULL,
  `tax_plan_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `type` tinytext COLLATE utf8_bin NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `rate_plan`
--

INSERT INTO `rate_plan` (`rate_plan_id`, `name`, `description`, `tax_plan_id`, `is_active`, `type`, `updated`, `updated_by`) VALUES
(1, 'Beginning Rate Climbing', '', 1, 1, 'A', '2012-03-05 19:21:23', 0),
(3, 'Beginning Rock Climbing', '', 0, 1, 'A', '0000-00-00 00:00:00', 0);
