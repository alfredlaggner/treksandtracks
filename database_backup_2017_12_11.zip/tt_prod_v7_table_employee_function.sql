
-- --------------------------------------------------------

--
-- Table structure for table `employee_function`
--

DROP TABLE IF EXISTS `employee_function`;
CREATE TABLE `employee_function` (
  `employee_function_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `short` tinytext NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee_function`
--

INSERT INTO `employee_function` (`employee_function_id`, `name`, `short`, `updated`, `updated_by`) VALUES
(1, 'Lead Guide', 'LG', '2013-05-29 00:00:23', 0),
(2, 'Assistant Guide', 'AG', '2013-05-29 00:01:08', 0),
(3, 'AMGA SPI', 'SPI', '2013-05-29 00:00:12', 0);
