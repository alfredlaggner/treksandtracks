
-- --------------------------------------------------------

--
-- Table structure for table `home_slider_picture`
--

DROP TABLE IF EXISTS `home_slider_picture`;
CREATE TABLE `home_slider_picture` (
  `home_slider_picture_id` int(11) NOT NULL,
  `home_slider_id` int(11) NOT NULL,
  `folder` varchar(30) COLLATE utf8_bin NOT NULL,
  `picture` varchar(30) COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `home_slider_picture`
--

INSERT INTO `home_slider_picture` (`home_slider_picture_id`, `home_slider_id`, `folder`, `picture`) VALUES
(3, 9, 'home_slider', 'KC2TT3.jpg'),
(8, 8, 'home_slider', 'BRCTT5.jpg'),
(11, 10, 'home_slider', 'oneper.jpg'),
(18, 11, 'home_slider', 'amga_spi.jpg'),
(7, 7, 'home_slider', 'mtn_cl.jpg'),
(17, 12, 'home_slider', 'TandT_logotr.gif');
