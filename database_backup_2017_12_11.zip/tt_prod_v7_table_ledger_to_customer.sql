
-- --------------------------------------------------------

--
-- Table structure for table `ledger_to_customer`
--

DROP TABLE IF EXISTS `ledger_to_customer`;
CREATE TABLE `ledger_to_customer` (
  `ledger_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `main_customer` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
