
-- --------------------------------------------------------

--
-- Table structure for table `gear`
--

DROP TABLE IF EXISTS `gear`;
CREATE TABLE `gear` (
  `gear_id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `code` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `order` int(11) NOT NULL,
  `price` double NOT NULL,
  `equipment_id` int(11) NOT NULL,
  `slogan` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `description_short` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `description_long` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `description_detailled` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `gear_group_id` int(11) NOT NULL,
  `division_id` int(11) NOT NULL,
  `is_featured` tinyint(1) NOT NULL,
  `is_active` tinyint(4) NOT NULL,
  `account_id` int(11) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gear`
--

INSERT INTO `gear` (`gear_id`, `name`, `code`, `order`, `price`, `equipment_id`, `slogan`, `description_short`, `description_long`, `description_detailled`, `gear_group_id`, `division_id`, `is_featured`, `is_active`, `account_id`, `updated`, `updated_by`) VALUES
(1, 'rope 1', 'GEAR1', 1, 0, 0, 'Sterling Nano', '', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>Check out this beautiful Sterling Nano rope. It\'s a great deal.</p>\n</body>\n</html>', '0', 1, 1, 1, 1, 0, '2014-03-15 05:39:05', 0),
(3, 'rope 2', 'GEAR2', 2, 0, 0, '', '', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n\n</body>\n</html>', '0', 2, 2, 1, 1, 1, '0000-00-00 00:00:00', 0),
(4, 'gear3', 'GEAR3', 5, 0, 0, 'aaa', 'a', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>a</p>\n</body>\n</html>', '0', 1, 2, 1, 1, 0, '2014-01-07 20:44:49', 0);
