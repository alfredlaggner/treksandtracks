
-- --------------------------------------------------------

--
-- Table structure for table `region`
--

DROP TABLE IF EXISTS `region`;
CREATE TABLE `region` (
  `region_id` int(11) NOT NULL,
  `region` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `region`
--

INSERT INTO `region` (`region_id`, `region`) VALUES
(1, 'Bay Area'),
(2, 'LA Area'),
(7, 'Seattle'),
(0, 'All Regions');
