
-- --------------------------------------------------------

--
-- Table structure for table `discount_type`
--

DROP TABLE IF EXISTS `discount_type`;
CREATE TABLE `discount_type` (
  `discount_type_id` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `discount_type`
--

INSERT INTO `discount_type` (`discount_type_id`, `type`, `name`, `description`, `updated`, `updated_by`) VALUES
(1, 1, 'Per Reservation', 'Applies to reservation total once before tax', '2011-12-13 04:02:32', 0),
(2, 2, 'Per Item', ' Applies to each item on the reservation before tax', '0000-00-00 00:00:00', 0),
(3, 3, 'Per Activity', 'Applies to total number of people on activities before tax', '2011-12-13 11:31:53', 0),
(5, 4, 'Per Accomodation', 'Applies to ONLY lodging before tax', '2011-12-13 11:33:07', 0),
(6, 5, 'Per AddOn', 'Applies ONLY to add-on before tax', '2011-12-13 11:33:38', 0),
(7, 6, 'Per Rental', 'Applies ONLY to Rental before tax', '2011-12-13 11:34:08', 0),
(8, 7, 'Per Purchase Item', 'Applies ONLY to Purchase Item before tax', '2011-12-13 11:34:52', 0),
(9, 8, 'Per Fee', 'Applies ONLY to Fees before tax', '2011-12-13 11:35:30', 0);
