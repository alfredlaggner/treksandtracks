
-- --------------------------------------------------------

--
-- Table structure for table `employee_cms`
--

DROP TABLE IF EXISTS `employee_cms`;
CREATE TABLE `employee_cms` (
  `employee_cms_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `cms_eff_date` date NOT NULL,
  `cms_amount` double(5,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `employee_cms`
--

INSERT INTO `employee_cms` (`employee_cms_id`, `employee_id`, `cms_eff_date`, `cms_amount`) VALUES
(1, 5, '2012-03-02', 3.00),
(2, 5, '2012-02-21', 2.50),
(3, 5, '2012-03-04', 34.00),
(4, 5, '2012-01-01', 67.00),
(5, 5, '2012-04-01', 10.00),
(6, 5, '2012-01-01', 16.00),
(7, 6, '2012-03-03', 20.00),
(8, 6, '2011-02-01', 10.00),
(9, 6, '2012-03-03', 20.00),
(10, 1, '2012-03-04', 12.00),
(11, 1, '2012-03-23', 15.00);
