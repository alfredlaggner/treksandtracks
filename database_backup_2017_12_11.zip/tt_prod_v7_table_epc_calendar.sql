
-- --------------------------------------------------------

--
-- Table structure for table `epc_calendar`
--

DROP TABLE IF EXISTS `epc_calendar`;
CREATE TABLE `epc_calendar` (
  `id` int(7) NOT NULL,
  `startDate` int(11) NOT NULL DEFAULT '0',
  `endDate` int(11) NOT NULL DEFAULT '0',
  `startTime` time NOT NULL DEFAULT '00:00:00',
  `endTime` time NOT NULL DEFAULT '00:00:00',
  `eventType` text COLLATE utf8_bin NOT NULL,
  `repeatx` int(7) NOT NULL DEFAULT '0',
  `title` text COLLATE utf8_bin NOT NULL,
  `descr` text COLLATE utf8_bin NOT NULL,
  `days` int(7) NOT NULL DEFAULT '0',
  `stop` int(7) NOT NULL DEFAULT '0',
  `month` tinyint(2) NOT NULL DEFAULT '0',
  `weekDay` tinyint(1) NOT NULL DEFAULT '0',
  `weekNumber` tinyint(1) NOT NULL DEFAULT '0',
  `category` text COLLATE utf8_bin NOT NULL,
  `eventKey` text COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `epc_calendar`
--

INSERT INTO `epc_calendar` (`id`, `startDate`, `endDate`, `startTime`, `endTime`, `eventType`, `repeatx`, `title`, `descr`, `days`, `stop`, `month`, `weekDay`, `weekNumber`, `category`, `eventKey`) VALUES
(1, 2455994, 2455994, '00:00:00', '00:00:00', 'Once', 0, 'test ', 'details ', 0, 0, 0, 0, 0, '0[1X', '');
