
-- --------------------------------------------------------

--
-- Table structure for table `stellar_sessions`
--

DROP TABLE IF EXISTS `stellar_sessions`;
CREATE TABLE `stellar_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `user_data` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
