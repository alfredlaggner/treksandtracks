
-- --------------------------------------------------------

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `news_id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `code` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `order` int(11) NOT NULL,
  `slogan` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `description_short` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `description_long` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `description_detailled` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `division_id` int(11) NOT NULL,
  `news_group_id` int(11) NOT NULL,
  `equipment_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `is_featured` tinyint(1) NOT NULL,
  `is_active` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`news_id`, `name`, `code`, `order`, `slogan`, `description_short`, `description_long`, `description_detailled`, `division_id`, `news_group_id`, `equipment_id`, `account_id`, `is_featured`, `is_active`) VALUES
(5, 'new news', 'NEWS1', 1, 'finally news', 'bla blah', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n\n</body>\n</html>', '0', 2, 4, 0, 0, 0, 1),
(6, 'new news', 'NEWS1', 1, 'finally news', 'bla blah', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\r\n<html>\r\n<head>\r\n<title>Untitled document</title>\r\n</head>\r\n<body>\r\n\r\n</body>\r\n</html>', '0', 0, 5, 0, 0, 0, 0),
(7, 'new news', 'NEWS1', 1, 'finally news', 'bla blah', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\r\n<html>\r\n<head>\r\n<title>Untitled document</title>\r\n</head>\r\n<body>\r\n\r\n</body>\r\n</html>', '0', 0, 5, 0, 0, 0, 0),
(9, 'news 2', 'NEWS2', 0, 'blah', '', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n\n</body>\n</html>', '0', 0, 5, 0, 0, 1, 0);
