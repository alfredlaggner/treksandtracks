
-- --------------------------------------------------------

--
-- Table structure for table `activity_to_region_old`
--

DROP TABLE IF EXISTS `activity_to_region_old`;
CREATE TABLE `activity_to_region_old` (
  `activity_id` int(11) NOT NULL,
  `region_id` int(11) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `activity_to_region_old`
--

INSERT INTO `activity_to_region_old` (`activity_id`, `region_id`, `updated`, `updated_by`) VALUES
(33, 1, '0000-00-00 00:00:00', 0),
(57, 2, '0000-00-00 00:00:00', 0),
(35, 2, '0000-00-00 00:00:00', 0),
(43, 3, '0000-00-00 00:00:00', 0),
(52, 2, '0000-00-00 00:00:00', 0),
(43, 2, '0000-00-00 00:00:00', 0),
(9, 0, '0000-00-00 00:00:00', 0),
(33, 2, '0000-00-00 00:00:00', 0),
(57, 1, '0000-00-00 00:00:00', 0),
(43, 1, '0000-00-00 00:00:00', 0),
(43, 0, '0000-00-00 00:00:00', 0);
