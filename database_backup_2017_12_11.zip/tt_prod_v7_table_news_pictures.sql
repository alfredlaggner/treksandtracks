
-- --------------------------------------------------------

--
-- Table structure for table `news_pictures`
--

DROP TABLE IF EXISTS `news_pictures`;
CREATE TABLE `news_pictures` (
  `news_picture_id` int(11) NOT NULL,
  `news_id` int(11) NOT NULL,
  `folder` varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `picture` varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
