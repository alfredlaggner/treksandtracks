
-- --------------------------------------------------------

--
-- Table structure for table `service_level`
--

DROP TABLE IF EXISTS `service_level`;
CREATE TABLE `service_level` (
  `service_level_id` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `service_level`
--

INSERT INTO `service_level` (`service_level_id`, `level`, `name`, `description`, `updated`, `updated_by`) VALUES
(1, 3, 'Family', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>Activities suitable for the entire family</p>\n</body>\n</html>', '2012-05-16 23:08:12', 0),
(3, 2, 'Adult', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>Activites suitable to people 12 and over.</p>\n</body>\n</html>', '2012-05-16 23:07:33', 0),
(4, 1, 'Child', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>Activities suitable for children between the ages of 7 and 14.</p>\n</body>\n</html>', '2012-05-16 23:07:47', 0);
