
-- --------------------------------------------------------

--
-- Table structure for table `gear_pictures`
--

DROP TABLE IF EXISTS `gear_pictures`;
CREATE TABLE `gear_pictures` (
  `gear_picture_id` int(11) NOT NULL,
  `gear_id` int(11) NOT NULL,
  `folder` varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `picture` varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gear_pictures`
--

INSERT INTO `gear_pictures` (`gear_picture_id`, `gear_id`, `folder`, `picture`) VALUES
(8, 1, 'gear1', 'GEAR12.jpg'),
(7, 1, 'gear1', 'GEAR11.jpg'),
(9, 1, 'gear1', 'GEAR13.jpg'),
(10, 1, 'gear1', 'GEAR14.jpg'),
(14, 3, 'GEAR2', 'GEAR21.jpg'),
(13, 1, 'gear1', 'GEAR17.jpg'),
(15, 3, 'GEAR2', 'GEAR22.jpg'),
(16, 3, 'GEAR2', 'GEAR23.jpg'),
(17, 3, 'GEAR2', 'GEAR24.jpg'),
(18, 3, 'GEAR2', 'GEAR25.jpg'),
(20, 4, 'GEAR3', 'GEAR32.jpg'),
(21, 4, 'GEAR3', 'GEAR31.jpg'),
(22, 4, 'GEAR3', 'GEAR33.jpg'),
(23, 4, 'GEAR3', 'GEAR34.jpg');
