
-- --------------------------------------------------------

--
-- Table structure for table `tax_plan`
--

DROP TABLE IF EXISTS `tax_plan`;
CREATE TABLE `tax_plan` (
  `tax_plan_id` int(11) NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tax_plan`
--

INSERT INTO `tax_plan` (`tax_plan_id`, `description`, `name`, `is_active`, `updated`, `updated_by`) VALUES
(1, 'CA State Parks', 'CA Mountain School', 1, '2012-02-09 03:20:20', 0);
