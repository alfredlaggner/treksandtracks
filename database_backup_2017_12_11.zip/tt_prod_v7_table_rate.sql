
-- --------------------------------------------------------

--
-- Table structure for table `rate`
--

DROP TABLE IF EXISTS `rate`;
CREATE TABLE `rate` (
  `rate_id` int(11) NOT NULL,
  `rate_plan_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `order` int(11) NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  `is_status_dependent` tinyint(1) NOT NULL,
  `status_dependent_text` varchar(255) COLLATE utf8_bin NOT NULL,
  `age_from` int(11) NOT NULL,
  `age_to` int(11) NOT NULL,
  `party_size_min` int(11) NOT NULL,
  `party_size_max` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `rate`
--

INSERT INTO `rate` (`rate_id`, `rate_plan_id`, `name`, `order`, `description`, `is_status_dependent`, `status_dependent_text`, `age_from`, `age_to`, `party_size_min`, `party_size_max`, `is_active`, `updated`, `updated_by`) VALUES
(6, 1, 'Beginning Rock Climbing', 1, 'rate 2012', 0, '', 5, 99, 0, 0, 1, '2012-02-09 09:04:03', 0);
