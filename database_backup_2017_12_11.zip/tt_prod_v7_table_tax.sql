
-- --------------------------------------------------------

--
-- Table structure for table `tax`
--

DROP TABLE IF EXISTS `tax`;
CREATE TABLE `tax` (
  `tax_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `authority` varchar(255) COLLATE utf8_bin NOT NULL,
  `amount_type` tinytext COLLATE utf8_bin NOT NULL,
  `person_or_reservation` tinytext COLLATE utf8_bin NOT NULL,
  `amount` decimal(7,2) NOT NULL,
  `order` int(11) NOT NULL,
  `is_exempt` tinyint(1) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tax`
--

INSERT INTO `tax` (`tax_id`, `name`, `authority`, `amount_type`, `person_or_reservation`, `amount`, `order`, `is_exempt`, `updated`, `updated_by`) VALUES
(1, 'Pinnakle User Fee', 'California Parks and Recreation Authority', 'P', 'R', '10.00', 1, 0, '2012-01-21 06:43:38', 0),
(3, 'State Park Fee', 'CA Park Authorities', 'P', 'R', '10.00', 2, 0, '2012-02-09 03:17:58', 0),
(4, 'California State Sales Tax', 'California State', 'P', 'R', '0.00', 1, 0, '2012-02-09 03:22:27', 0),
(5, 'Colorada Sales Tax', 'Colorado State', 'P', 'R', '3.78', 2, 0, '0000-00-00 00:00:00', 0),
(7, 'Utah Sales Tax', 'Utah', 'P', 'P', '12.00', 4, 0, '0000-00-00 00:00:00', 0);
