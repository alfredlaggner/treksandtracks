
-- --------------------------------------------------------

--
-- Table structure for table `division`
--

DROP TABLE IF EXISTS `division`;
CREATE TABLE `division` (
  `division_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `division`
--

INSERT INTO `division` (`division_id`, `name`, `description`, `updated`, `updated_by`) VALUES
(1, 'Mountain School', 'All the rock climbing events everywhere', '2012-02-09 02:09:20', 0),
(2, 'Expeditions', 'All horseback events', '2012-02-09 02:08:22', 0);
