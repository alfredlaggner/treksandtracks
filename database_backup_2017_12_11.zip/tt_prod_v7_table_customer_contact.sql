
-- --------------------------------------------------------

--
-- Table structure for table `customer_contact`
--

DROP TABLE IF EXISTS `customer_contact`;
CREATE TABLE `customer_contact` (
  `customer_contact_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `entered_at` datetime NOT NULL,
  `type_id` varchar(1) COLLATE utf8_bin NOT NULL,
  `note` text COLLATE utf8_bin NOT NULL,
  `group` varchar(1) COLLATE utf8_bin NOT NULL,
  `mail_id` int(11) NOT NULL,
  `next_contact` date NOT NULL,
  `employee_id` int(11) NOT NULL,
  `contact_of` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `customer_contact`
--

INSERT INTO `customer_contact` (`customer_contact_id`, `customer_id`, `entered_at`, `type_id`, `note`, `group`, `mail_id`, `next_contact`, `employee_id`, `contact_of`) VALUES
(1, 1, '2012-07-02 05:00:34', '7', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>sss</p>\n</body>\n</html>', '', 0, '0000-00-00', 1, 0),
(2, 1, '2012-07-02 05:09:17', '7', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>bbbbb</p>\n</body>\n</html>', '', 0, '0000-00-00', 1, 0),
(3, 1, '2012-07-02 05:09:17', '7', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>bbbbb</p>\n</body>\n</html>', '', 0, '0000-00-00', 1, 0),
(4, 29, '2012-07-02 10:34:21', '7', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>xxxx</p>\n</body>\n</html>', '', 0, '0000-00-00', 1, 0),
(5, 41, '2012-07-02 15:44:16', '7', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>jkggh</p>\n</body>\n</html>', '', 0, '0000-00-00', 1, 0),
(6, 1, '2012-07-18 07:45:41', '3', '[Puerto_Vallarta_OldTown_SouthSide] Digest Number 3618', '', 281, '0000-00-00', 0, 0),
(7, 160, '2012-07-19 10:12:39', '7', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n\n</body>\n</html>', '', 0, '0000-00-00', 8, 0),
(8, 124, '2012-07-22 11:40:58', '7', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>a</p>\n</body>\n</html>', '', 0, '0000-00-00', 8, 0),
(9, 41, '2012-07-24 02:22:05', '7', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>customer could not figure out his Groupon code. He emailed it to me and I found the number in the system. He used the code 100 to zero out his bill.&nbsp;</p>\n</body>\n</html>', '', 0, '2012-07-31', 5, 0),
(10, 41, '2012-07-24 02:22:05', '7', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>customer could not figure out his Groupon code. He emailed it to me and I found the number in the system. He used the code 100 to zero out his bill.&nbsp;</p>\n</body>\n</html>', '', 0, '2012-07-31', 5, 0),
(11, 30, '2012-07-24 02:27:54', '7', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>customer could not figure out his Groupon code. He emailed it to me and I found the number in the system. He used the code 100 to zero out his bill.&nbsp;</p>\n</body>\n</html>', '', 0, '0000-00-00', 5, 0),
(12, 41, '2012-07-24 02:22:05', '7', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>customer could not figure out his Groupon code. He emailed it to me and I found the number in the system. He used the code 100 to zero out his bill.&nbsp;</p>\n</body>\n</html>', '', 0, '2012-07-31', 5, 0),
(13, 68, '2013-07-24 20:48:03', '3', 'Your Facebook app on Heroku', '', 276, '0000-00-00', 0, 0),
(14, 7264, '2014-04-11 08:16:45', '7', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>PAID the rest. Reservation complete</p>\n</body>\n</html>', '', 0, '0000-00-00', 6, 0);
