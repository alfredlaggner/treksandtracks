
-- --------------------------------------------------------

--
-- Table structure for table `news_group`
--

DROP TABLE IF EXISTS `news_group`;
CREATE TABLE `news_group` (
  `news_group_id` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news_group`
--

INSERT INTO `news_group` (`news_group_id`, `order`, `name`, `description`, `updated`, `updated_by`) VALUES
(4, 0, 'group1', '', '2014-03-25 00:43:21', 0),
(5, 0, 'group2', '', '2014-03-25 00:43:21', 0);
