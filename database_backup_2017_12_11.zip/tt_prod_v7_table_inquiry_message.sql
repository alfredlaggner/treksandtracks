
-- --------------------------------------------------------

--
-- Table structure for table `inquiry_message`
--

DROP TABLE IF EXISTS `inquiry_message`;
CREATE TABLE `inquiry_message` (
  `inquiry_message_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `inquiry_message`
--

INSERT INTO `inquiry_message` (`inquiry_message_id`, `name`, `description`, `updated`, `updated_by`) VALUES
(1, '[Activity name] with Treks and Tracks is around the corner', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>Hi [customer first name],</p>\n<p>&nbsp;</p>\n<p>We wanted to remind you that your&nbsp;[activity name,] at [activity location] at [activity time] is around the corner. &nbsp;When you arrive look for the guide(s) in the Orange t-shirt.</p>\n<p>Please be sure to bring:</p>\n<p>[activity_you bring]</p>\n<p>We look forward to seeing you in a couple of days. If you have any questions please don\'t hesitate to contact us.</p>\n<p>In the event you cannot attend this activity, we ask that you pleae let us know by replying to this email.</p>\n<p>&nbsp;</p>\n<p>Best,&nbsp;</p>\n<p>The Treks and Tracks team</p>\n<p><img src="http://i848.photobucket.com/albums/ab44/adventurepics_2010/TandT_new_logolower_small.png" alt="" width="100" height="75" /></p>\n<p>Telephone Bay Area: (650) 557-4893<br style="margin: 0px; padding: 0px; vertical-align: baseline; outline: 0px; background-color: transparent; color: #444444; font-family: Comfortaa, sans-serif; font-size: 12px; line-height: 18px;" />Telephone LA Area: (323) 522-5046</p>\n</body>\n</html>', '2012-06-27 21:06:13', 0),
(2, 'Thank you for attending [Activity Name]', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>&nbsp;</p>\n<p>Hi [customer first name],</p>\n<p>&nbsp;</p>\n<p>We wanted to say thank you attending [activity name]</p>\n<p>We\'d love to stay in touch with you&nbsp;</p>\n<p>We look forward to seeing you in a couple of days. If you have any questions please don\'t hesitate to contact us.</p>\n<p>In the event you cannot attend this activity, we ask that you pleae let us know by replying to this email.</p>\n<p>&nbsp;</p>\n<p>Best,&nbsp;</p>\n<p>The Treks and Tracks team</p>\n<p><img src="http://i848.photobucket.com/albums/ab44/adventurepics_2010/TandT_new_logolower_small.png" alt="" width="100" height="75" /></p>\n<p>Telephone Bay Area: (650) 557-4893<br style="margin: 0px; padding: 0px; vertical-align: baseline; outline: 0px; background-color: transparent; color: #444444; font-family: Comfortaa, sans-serif; font-size: 12px; line-height: 18px;" />Telephone LA Area: (323) 522-5046</p>\n<p>&nbsp;</p>\n</body>\n</html>', '2012-06-27 21:06:33', 0),
(4, 'Bring a friend and save [send after 40 days]', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>\n<p>Hi [customer first name],</p>\n<p>&nbsp;</p>\n<p>We wanted to say thank you attending [activity name] some time back. We just wanted to let you know that we have a special offer going right now. We think you would really love our [suggested activity 1]. Right now if you sign up for this Activity and you bring at least one friend, the whole group save 20% each on the class.&nbsp;</p>\n<p>Just use the promotion code: WX20DC when you and your fiends sign up.</p>\n<p>We hope to see you out with us soon!</p>\n<p>Best,&nbsp;</p>\n<p>The Treks and Tracks team</p>\n<p><img src="http://i848.photobucket.com/albums/ab44/adventurepics_2010/TandT_new_logolower_small.png" alt="" width="100" height="75" /></p>\n<p>Telephone Bay Area: (650) 557-4893<br style="margin: 0px; padding: 0px; vertical-align: baseline; outline: 0px; background-color: transparent; color: #444444; font-family: Comfortaa, sans-serif; font-size: 12px; line-height: 18px;" />Telephone LA Area: (323) 522-5046</p>\n</p>\n</body>\n</html>', '2012-06-27 08:40:52', 0);
