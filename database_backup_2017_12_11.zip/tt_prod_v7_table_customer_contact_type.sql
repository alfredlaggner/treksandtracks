
-- --------------------------------------------------------

--
-- Table structure for table `customer_contact_type`
--

DROP TABLE IF EXISTS `customer_contact_type`;
CREATE TABLE `customer_contact_type` (
  `customer_contact_type_id` int(11) NOT NULL,
  `code` varchar(2) COLLATE utf8_bin NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `customer_contact_type`
--

INSERT INTO `customer_contact_type` (`customer_contact_type_id`, `code`, `name`, `description`, `updated`, `updated_by`) VALUES
(3, 'MI', 'eMail Incoming', 'all incoming emails', '2012-02-17 02:16:47', 0),
(5, 'MO', 'eMail Outgoing', 'not easy', '2012-02-17 02:16:54', 0),
(6, 'VM', 'Voice Message', 'hard but cool', '2012-02-17 02:17:03', 0),
(7, 'AA', 'Note', 'just a note', '2012-02-22 04:20:22', 0),
(8, 'OT', 'Other', 'for experts only, but doable', '2012-02-17 02:17:22', 0);
