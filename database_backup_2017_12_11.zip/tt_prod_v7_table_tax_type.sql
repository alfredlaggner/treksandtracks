
-- --------------------------------------------------------

--
-- Table structure for table `tax_type`
--

DROP TABLE IF EXISTS `tax_type`;
CREATE TABLE `tax_type` (
  `tax_type_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
