
-- --------------------------------------------------------

--
-- Table structure for table `style`
--

DROP TABLE IF EXISTS `style`;
CREATE TABLE `style` (
  `style_id` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  `carousel_picture` varchar(50) COLLATE utf8_bin NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `slogan` text COLLATE utf8_bin NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `style`
--

INSERT INTO `style` (`style_id`, `order`, `carousel_picture`, `name`, `slogan`, `is_active`, `description`, `updated`, `updated_by`) VALUES
(1, 1, 'backpacking.jpg', 'Backpacking', 'An unforgettable group experience.', 1, 'Choose between one or two nights.\r\nWe provide the equipment.\r\n', '2016-12-13 23:08:28', 0),
(2, 2, 'rock_climbing.jpg', 'Rock Climbing', 'Overcome inner resistance and rise to new levels', 1, 'Gain strength -\r\nLearn to collaborate - \r\nHave fun', '2016-12-13 23:09:13', 1),
(4, 4, '0', 'Winter', '', 0, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n\n</body>\n</html>', '2012-06-23 02:26:46', 0),
(6, 5, 'survival.jpg', 'Survival', 'Learn to survive', 1, '<p>Make a fire without a match. Build a shelter. Find edibles.&nbsp;</p>', '2016-12-13 23:20:50', 0),
(8, 6, '0', 'Group Activities', '', 0, '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\r\n<html>\r\n<head>\r\n<title>Untitled document</title>\r\n</head>\r\n<body>\r\n\r\n</body>\r\n</html>', '2016-05-16 03:31:25', 0);
