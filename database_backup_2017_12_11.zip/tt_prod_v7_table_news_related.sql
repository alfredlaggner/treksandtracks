
-- --------------------------------------------------------

--
-- Table structure for table `news_related`
--

DROP TABLE IF EXISTS `news_related`;
CREATE TABLE `news_related` (
  `news_id` int(11) NOT NULL,
  `news_related_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `news_related`
--

INSERT INTO `news_related` (`news_id`, `news_related_id`) VALUES
(1, 3),
(3, 3),
(3, 4),
(4, 1),
(4, 3),
(5, 9),
(5, 7);
