
-- --------------------------------------------------------

--
-- Table structure for table `event_save`
--

DROP TABLE IF EXISTS `event_save`;
CREATE TABLE `event_save` (
  `event_id` int(11) NOT NULL,
  `activity_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `duration` int(11) NOT NULL,
  `capacity_max` int(11) NOT NULL,
  `available` int(11) NOT NULL,
  `attending` int(11) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL,
  `data` text COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
