
-- --------------------------------------------------------

--
-- Table structure for table `physical_level`
--

DROP TABLE IF EXISTS `physical_level`;
CREATE TABLE `physical_level` (
  `physical_level_id` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `physical_level`
--

INSERT INTO `physical_level` (`physical_level_id`, `level`, `name`, `description`, `updated`, `updated_by`) VALUES
(3, 0, 'Easy', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>Class style activity. Hiking on flat to moderately hilly ground may be involved.</p>\n</body>\n</html>', '2012-05-16 22:51:15', 0),
(5, 0, 'Moderate', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>Hiking on uneven ground and physical excursion is involved. You should feel comfortable hiking 1-2 miles.</p>\n</body>\n</html>', '2012-05-16 22:51:27', 0),
(6, 0, 'Moderate+', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>Hiking on uneven ground and physical excursion is involved. You should feel comfortable hiking 1-2 miles. Physical activity such as rock climbing or moving in snowy terrain may be involved. Be ready for a good day of exercise.</p>\n</body>\n</html>', '2012-05-16 22:53:29', 0),
(7, 0, 'Strenouos', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>All day of activities in a variety of terrains are possible. You should feel comfortable hiking 5 miles with a pack. &nbsp;You should be called a fit person by your friends in order to feel comfortable.&nbsp;</p>\n</body>\n</html>', '2012-05-16 22:56:04', 0),
(8, 0, 'Expert', 'for experts only, but doable', '2012-02-08 00:37:26', 0);
