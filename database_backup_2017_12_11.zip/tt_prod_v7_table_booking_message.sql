
-- --------------------------------------------------------

--
-- Table structure for table `booking_message`
--

DROP TABLE IF EXISTS `booking_message`;
CREATE TABLE `booking_message` (
  `booking_message_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `booking_message`
--

INSERT INTO `booking_message` (`booking_message_id`, `name`, `description`, `updated`, `updated_by`) VALUES
(3, 'We look forward to seeing you at Castle Rock State Park', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>\n<p style="font-family: sans-serif; font-size: 14px;">Dear Climbing Enthusiasts!</p>\n<p style="font-family: sans-serif; font-size: 14px;">&nbsp;</p>\n<p style="font-family: sans-serif; font-size: 14px;">We look forward to a good day of outdoor rock climbing at&nbsp;Castle Rock State Park&nbsp;on Saturday May 12th. The weather looks&nbsp;sunny and&nbsp;clear, with highs in the 70\'s.</p>\n<p style="font-family: sans-serif; font-size: 14px;">Please remember to bring:</p>\n<p style="font-family: sans-serif; font-size: 14px;">- An extra layer for warmth and/or sun exposure</p>\n<p style="font-family: sans-serif; font-size: 14px;">- Water</p>\n<p style="font-family: sans-serif; font-size: 14px;">- A snack</p>\n<p style="font-family: sans-serif; font-size: 14px;">- A small day pack (to carry harness,&nbsp;climbing shoes and helmets that we will provide)</p>\n<p style="font-family: sans-serif; font-size: 14px;">- Your Groupon voucher (unless you\'ve emailed&nbsp;us the number already)</p>\n<p style="font-family: sans-serif; font-size: 14px;">&nbsp;</p>\n<p style="font-family: sans-serif; font-size: 14px;">The approach to our climbing site will take 15-20 minutes and sturdy footwear will make things easier.</p>\n<p style="font-family: sans-serif; font-size: 14px;">If you cannot make it tomorrow, please email us at&nbsp;<a href="mailto:info@treksandtracks.com">info@treksandtracks.com</a>.</p>\n<p style="font-family: sans-serif; font-size: 14px;">Your guide will be Daniel, who can be reached at either&nbsp;<a href="mailto:daniel@treksandtracks.com">daniel@treksandtracks.com</a>&nbsp;or via phone at (831)332-6726.</p>\n<p style="font-family: sans-serif; font-size: 14px;">&nbsp;</p>\n<p style="font-family: sans-serif; font-size: 14px;"><em>Our guides deeply appreciate gratuity for their efforts in creating a safe and fun environment in an inherently dangerous sport.</em></p>\n<p style="font-family: sans-serif; font-size: 14px;">&nbsp;</p>\n<p style="font-family: sans-serif; font-size: 14px;">For directions to Castle Rock State Park, see our Beginning Rock Climbing Page at&nbsp;<a href="http://treksandtracks.com/rock-climbing-beginner.shtml">http://treksandtracks.com/rock-climbing-beginner.shtml</a>.</p>\n<p style="font-family: sans-serif; font-size: 14px;">&nbsp;</p>\n<p style="font-family: sans-serif; font-size: 14px;">Look for the Treks and Tracks sign in the Castle Rock State Park parking lot.</p>\n<p style="font-family: sans-serif; font-size: 14px;">&nbsp;</p>\n<p style="font-family: sans-serif; font-size: 14px;">&nbsp;- The Treks and Tracks Team</p>\n</p>\n</body>\n</html>', '2012-05-16 23:14:14', 0);
