
-- --------------------------------------------------------

--
-- Table structure for table `coordinates`
--

DROP TABLE IF EXISTS `coordinates`;
CREATE TABLE `coordinates` (
  `coordinates_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `longitude` float NOT NULL,
  `latitude` float NOT NULL,
  `location` varchar(255) COLLATE utf8_bin NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `coordinates`
--

INSERT INTO `coordinates` (`coordinates_id`, `location_id`, `longitude`, `latitude`, `location`, `updated`, `updated_by`) VALUES
(1, 5, -122.096, 37.2306, 'Castle Rock Park', '2016-07-03 05:23:03', 0),
(2, 6, -118.604, 34.2747, 'ROCKRIDGE', '2016-07-08 01:03:02', 0),
(3, 10, -119.165, 34.5602, 'Sespe River Trail', '2017-01-05 02:23:13', 0),
(4, 23, -122.031, 36.9854, 'Headquarters', '0000-00-00 00:00:00', 0),
(5, 24, -119.687, 37.5732, 'Alder Creek', '2016-07-02 18:59:23', 0),
(6, 21, -123.935, 47.8609, 'Hoh Visitor Center', '0000-00-00 00:00:00', 0),
(7, 18, 12219, 12999, 'Exit 38', '0000-00-00 00:00:00', 0),
(8, 20, -124.599, 48.3684, 'Makah Cultural & Research Center', '2016-12-25 19:12:13', 0),
(10, 25, -119.598, 37.7439, 'Yosemite Lodge', '0000-00-00 00:00:00', 0),
(11, 13, -122.747, 37.9341, 'Point Reyes', '0000-00-00 00:00:00', 0),
(14, 12, -119.598, 37.7439, 'Yosemite National Park - Glacier Point', '0000-00-00 00:00:00', 0),
(13, 19, -119.572, 37.7379, '', '2016-12-26 17:11:00', 0),
(15, 8, -118.731, 34.098, 'Malibu Creek State Park', '2017-01-25 17:34:42', 0),
(16, 15, -121.164, 36.4874, 'Pinnacles National Park', '2017-03-11 23:23:55', 0);
