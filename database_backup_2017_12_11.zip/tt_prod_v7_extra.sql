
--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`account_id`),
  ADD KEY `employee_id` (`employee_id`),
  ADD KEY `priority` (`priority`);

--
-- Indexes for table `activity`
--
ALTER TABLE `activity`
  ADD PRIMARY KEY (`activity_id`),
  ADD KEY `style` (`style_id`),
  ADD KEY `service_level` (`service_level_id`),
  ADD KEY `active_yn` (`is_active`),
  ADD KEY `division_id` (`division_id`),
  ADD KEY `confirmation_message_id` (`confirmation_message_id`),
  ADD KEY `physical_level_id` (`physical_level_id`),
  ADD KEY `deposit_plan_individual_id` (`deposit_plan_individual_id`),
  ADD KEY `deposit_plan_igroup_id` (`deposit_plan_group_id`),
  ADD KEY `cancel_plan_individual_id` (`cancel_plan_individual_id`),
  ADD KEY `cancel_plan_group_id` (`cancel_plan_group_id`),
  ADD KEY `location_id` (`location_id`),
  ADD KEY `order` (`order`);

--
-- Indexes for table `activity_pictures`
--
ALTER TABLE `activity_pictures`
  ADD PRIMARY KEY (`activity_picture_id`,`picture`);

--
-- Indexes for table `activity_to_location`
--
ALTER TABLE `activity_to_location`
  ADD KEY `location_id` (`location_id`),
  ADD KEY `product_id` (`activity_id`);

--
-- Indexes for table `activity_to_region`
--
ALTER TABLE `activity_to_region`
  ADD KEY `location_id` (`region_id`),
  ADD KEY `product_id` (`activity_id`);

--
-- Indexes for table `activity_to_region_old`
--
ALTER TABLE `activity_to_region_old`
  ADD KEY `location_id` (`region_id`),
  ADD KEY `product_id` (`activity_id`);

--
-- Indexes for table `attachment`
--
ALTER TABLE `attachment`
  ADD PRIMARY KEY (`attachment_id`);

--
-- Indexes for table `auth_sessions`
--
ALTER TABLE `auth_sessions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booking_message`
--
ALTER TABLE `booking_message`
  ADD PRIMARY KEY (`booking_message_id`);

--
-- Indexes for table `BP_Pt_Reyes`
--
ALTER TABLE `BP_Pt_Reyes`
  ADD PRIMARY KEY (`discount_id`),
  ADD UNIQUE KEY `promo_code` (`promo_code`(30));

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD KEY `ci_sessions_timestamp` (`timestamp`);

--
-- Indexes for table `confirmation_message`
--
ALTER TABLE `confirmation_message`
  ADD PRIMARY KEY (`confirmation_message_id`);

--
-- Indexes for table `coordinates`
--
ALTER TABLE `coordinates`
  ADD PRIMARY KEY (`coordinates_id`),
  ADD KEY `location_id` (`location_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`),
  ADD KEY `physical_condition_id` (`physical_condition_id`);

--
-- Indexes for table `customer_contact`
--
ALTER TABLE `customer_contact`
  ADD PRIMARY KEY (`customer_contact_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `contact_of` (`contact_of`);

--
-- Indexes for table `customer_contact_type`
--
ALTER TABLE `customer_contact_type`
  ADD PRIMARY KEY (`customer_contact_type_id`);

--
-- Indexes for table `customer_questionaire`
--
ALTER TABLE `customer_questionaire`
  ADD PRIMARY KEY (`customer_questionaire_id`);

--
-- Indexes for table `denied_access`
--
ALTER TABLE `denied_access`
  ADD PRIMARY KEY (`ai`);

--
-- Indexes for table `discount`
--
ALTER TABLE `discount`
  ADD PRIMARY KEY (`discount_id`),
  ADD UNIQUE KEY `promo_code` (`promo_code`(30));

--
-- Indexes for table `discount_bad`
--
ALTER TABLE `discount_bad`
  ADD PRIMARY KEY (`discount_id`),
  ADD UNIQUE KEY `promo_code` (`promo_code`(30));

--
-- Indexes for table `discount_to_activity`
--
ALTER TABLE `discount_to_activity`
  ADD UNIQUE KEY `discount_id` (`discount_id`,`activity_id`);

--
-- Indexes for table `discount_to_activity_bad`
--
ALTER TABLE `discount_to_activity_bad`
  ADD UNIQUE KEY `discount_id` (`discount_id`,`activity_id`);

--
-- Indexes for table `discount_to_activity_work`
--
ALTER TABLE `discount_to_activity_work`
  ADD UNIQUE KEY `discount_id` (`discount_id`,`activity_id`);

--
-- Indexes for table `discount_type`
--
ALTER TABLE `discount_type`
  ADD PRIMARY KEY (`discount_type_id`),
  ADD UNIQUE KEY `type` (`type`);

--
-- Indexes for table `discount_work`
--
ALTER TABLE `discount_work`
  ADD UNIQUE KEY `promo_code` (`promo_code`(30));

--
-- Indexes for table `discount_work-old`
--
ALTER TABLE `discount_work-old`
  ADD UNIQUE KEY `promo_code` (`promo_code`(30));

--
-- Indexes for table `division`
--
ALTER TABLE `division`
  ADD PRIMARY KEY (`division_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `employee_cms`
--
ALTER TABLE `employee_cms`
  ADD PRIMARY KEY (`employee_cms_id`),
  ADD KEY `employee_id` (`employee_id`,`cms_eff_date`);

--
-- Indexes for table `employee_function`
--
ALTER TABLE `employee_function`
  ADD PRIMARY KEY (`employee_function_id`);

--
-- Indexes for table `employee_org`
--
ALTER TABLE `employee_org`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `epc_calendar`
--
ALTER TABLE `epc_calendar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`equipment_id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`event_id`),
  ADD KEY `date` (`date`),
  ADD KEY `instructor_id` (`location_id`),
  ADD KEY `activity_id_id` (`activity_id`);

--
-- Indexes for table `event_save`
--
ALTER TABLE `event_save`
  ADD PRIMARY KEY (`event_id`),
  ADD KEY `date` (`date`),
  ADD KEY `instructor_id` (`location_id`),
  ADD KEY `activity_id_id` (`activity_id`);

--
-- Indexes for table `event_to_employee`
--
ALTER TABLE `event_to_employee`
  ADD PRIMARY KEY (`event_id`,`employee_id`),
  ADD KEY `employee_id` (`employee_id`,`event_id`);

--
-- Indexes for table `event_work`
--
ALTER TABLE `event_work`
  ADD KEY `date` (`date`),
  ADD KEY `instructor_id` (`location_id`),
  ADD KEY `activity_id_id` (`activity_id`);

--
-- Indexes for table `gear`
--
ALTER TABLE `gear`
  ADD PRIMARY KEY (`gear_id`),
  ADD KEY `style` (`gear_group_id`),
  ADD KEY `division_id` (`division_id`),
  ADD KEY `order` (`order`);

--
-- Indexes for table `gear_group`
--
ALTER TABLE `gear_group`
  ADD PRIMARY KEY (`gear_group_id`),
  ADD KEY `order` (`order`);

--
-- Indexes for table `gear_pictures`
--
ALTER TABLE `gear_pictures`
  ADD PRIMARY KEY (`gear_picture_id`,`picture`);

--
-- Indexes for table `gear_to_region`
--
ALTER TABLE `gear_to_region`
  ADD KEY `location_id` (`region_id`),
  ADD KEY `product_id` (`gear_id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `home_slider`
--
ALTER TABLE `home_slider`
  ADD PRIMARY KEY (`home_slider_id`),
  ADD KEY `active_yn` (`is_active`),
  ADD KEY `order` (`order`);

--
-- Indexes for table `home_slider_picture`
--
ALTER TABLE `home_slider_picture`
  ADD PRIMARY KEY (`home_slider_picture_id`,`picture`);

--
-- Indexes for table `inquiry_message`
--
ALTER TABLE `inquiry_message`
  ADD PRIMARY KEY (`inquiry_message_id`);

--
-- Indexes for table `ips_on_hold`
--
ALTER TABLE `ips_on_hold`
  ADD PRIMARY KEY (`ai`);

--
-- Indexes for table `ledger`
--
ALTER TABLE `ledger`
  ADD PRIMARY KEY (`ledger_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `ledger_to_customer`
--
ALTER TABLE `ledger_to_customer`
  ADD PRIMARY KEY (`ledger_id`,`customer_id`),
  ADD UNIQUE KEY `customer_id` (`customer_id`,`ledger_id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`location_id`),
  ADD UNIQUE KEY `code` (`code`(191)),
  ADD KEY `name` (`name`(191)),
  ADD KEY `city` (`city`(191)),
  ADD KEY `state` (`state`(191)),
  ADD KEY `country` (`country`(191)),
  ADD KEY `continent` (`continent`(191));

--
-- Indexes for table `login_errors`
--
ALTER TABLE `login_errors`
  ADD PRIMARY KEY (`ai`);

--
-- Indexes for table `mail`
--
ALTER TABLE `mail`
  ADD PRIMARY KEY (`mail_id`),
  ADD KEY `from` (`from`),
  ADD KEY `to` (`to`),
  ADD KEY `status` (`status`),
  ADD KEY `is_incoming` (`is_incoming`),
  ADD KEY `date_time` (`date_time`);

--
-- Indexes for table `meta`
--
ALTER TABLE `meta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`news_id`),
  ADD KEY `division_id` (`division_id`),
  ADD KEY `order` (`order`);

--
-- Indexes for table `news_group`
--
ALTER TABLE `news_group`
  ADD PRIMARY KEY (`news_group_id`),
  ADD KEY `order` (`order`);

--
-- Indexes for table `news_pictures`
--
ALTER TABLE `news_pictures`
  ADD PRIMARY KEY (`news_picture_id`,`picture`);

--
-- Indexes for table `news_to_region`
--
ALTER TABLE `news_to_region`
  ADD KEY `location_id` (`region_id`),
  ADD KEY `product_id` (`news_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `physical_level`
--
ALTER TABLE `physical_level`
  ADD PRIMARY KEY (`physical_level_id`);

--
-- Indexes for table `rate`
--
ALTER TABLE `rate`
  ADD PRIMARY KEY (`rate_id`),
  ADD KEY `name` (`name`,`order`,`age_from`,`age_to`),
  ADD KEY `party_size_min` (`party_size_min`),
  ADD KEY `party_size_max` (`party_size_max`),
  ADD KEY `rate_plan_id` (`order`),
  ADD KEY `rate_pland_id` (`rate_plan_id`);

--
-- Indexes for table `rate_plan`
--
ALTER TABLE `rate_plan`
  ADD PRIMARY KEY (`rate_plan_id`),
  ADD KEY `name` (`name`,`tax_plan_id`);

--
-- Indexes for table `rate_plan_to_rate`
--
ALTER TABLE `rate_plan_to_rate`
  ADD KEY `rate_plan_id` (`rate_plan_id`,`rate_id`);

--
-- Indexes for table `rate_price`
--
ALTER TABLE `rate_price`
  ADD PRIMARY KEY (`rate_price_id`),
  ADD KEY `effective_date` (`effective_date`),
  ADD KEY `activity_id` (`activity_id`);

--
-- Indexes for table `region`
--
ALTER TABLE `region`
  ADD PRIMARY KEY (`region_id`);

--
-- Indexes for table `service_level`
--
ALTER TABLE `service_level`
  ADD PRIMARY KEY (`service_level_id`);

--
-- Indexes for table `stellar_sessions`
--
ALTER TABLE `stellar_sessions`
  ADD PRIMARY KEY (`session_id`),
  ADD KEY `last_activity_idx` (`last_activity`);

--
-- Indexes for table `style`
--
ALTER TABLE `style`
  ADD PRIMARY KEY (`style_id`),
  ADD KEY `order` (`order`);

--
-- Indexes for table `tax`
--
ALTER TABLE `tax`
  ADD PRIMARY KEY (`tax_id`);

--
-- Indexes for table `tax_plan`
--
ALTER TABLE `tax_plan`
  ADD PRIMARY KEY (`tax_plan_id`);

--
-- Indexes for table `tax_plan_to_tax`
--
ALTER TABLE `tax_plan_to_tax`
  ADD UNIQUE KEY `tax_plan_id` (`tax_plan_id`,`tax_id`);

--
-- Indexes for table `tax_type`
--
ALTER TABLE `tax_type`
  ADD PRIMARY KEY (`tax_type_id`);

--
-- Indexes for table `template`
--
ALTER TABLE `template`
  ADD PRIMARY KEY (`template_id`),
  ADD KEY `name` (`name`(50));

--
-- Indexes for table `template_to_attachment`
--
ALTER TABLE `template_to_attachment`
  ADD PRIMARY KEY (`template_id`,`attachment_id`),
  ADD KEY `employee_id` (`attachment_id`,`template_id`);

--
-- Indexes for table `username_or_email_on_hold`
--
ALTER TABLE `username_or_email_on_hold`
  ADD PRIMARY KEY (`ai`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_auth`
--
ALTER TABLE `users_auth`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `account_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `activity`
--
ALTER TABLE `activity`
  MODIFY `activity_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;
--
-- AUTO_INCREMENT for table `activity_pictures`
--
ALTER TABLE `activity_pictures`
  MODIFY `activity_picture_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=211;
--
-- AUTO_INCREMENT for table `attachment`
--
ALTER TABLE `attachment`
  MODIFY `attachment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `booking_message`
--
ALTER TABLE `booking_message`
  MODIFY `booking_message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `BP_Pt_Reyes`
--
ALTER TABLE `BP_Pt_Reyes`
  MODIFY `discount_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45102;
--
-- AUTO_INCREMENT for table `confirmation_message`
--
ALTER TABLE `confirmation_message`
  MODIFY `confirmation_message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `coordinates`
--
ALTER TABLE `coordinates`
  MODIFY `coordinates_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15532;
--
-- AUTO_INCREMENT for table `customer_contact`
--
ALTER TABLE `customer_contact`
  MODIFY `customer_contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `customer_contact_type`
--
ALTER TABLE `customer_contact_type`
  MODIFY `customer_contact_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `customer_questionaire`
--
ALTER TABLE `customer_questionaire`
  MODIFY `customer_questionaire_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1809;
--
-- AUTO_INCREMENT for table `denied_access`
--
ALTER TABLE `denied_access`
  MODIFY `ai` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `discount`
--
ALTER TABLE `discount`
  MODIFY `discount_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52330;
--
-- AUTO_INCREMENT for table `discount_bad`
--
ALTER TABLE `discount_bad`
  MODIFY `discount_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50307;
--
-- AUTO_INCREMENT for table `discount_type`
--
ALTER TABLE `discount_type`
  MODIFY `discount_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `division`
--
ALTER TABLE `division`
  MODIFY `division_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT for table `employee_cms`
--
ALTER TABLE `employee_cms`
  MODIFY `employee_cms_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `employee_function`
--
ALTER TABLE `employee_function`
  MODIFY `employee_function_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `employee_org`
--
ALTER TABLE `employee_org`
  MODIFY `employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `epc_calendar`
--
ALTER TABLE `epc_calendar`
  MODIFY `id` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `equipment`
--
ALTER TABLE `equipment`
  MODIFY `equipment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1625;
--
-- AUTO_INCREMENT for table `event_save`
--
ALTER TABLE `event_save`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gear`
--
ALTER TABLE `gear`
  MODIFY `gear_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `gear_group`
--
ALTER TABLE `gear_group`
  MODIFY `gear_group_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `gear_pictures`
--
ALTER TABLE `gear_pictures`
  MODIFY `gear_picture_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `home_slider`
--
ALTER TABLE `home_slider`
  MODIFY `home_slider_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `home_slider_picture`
--
ALTER TABLE `home_slider_picture`
  MODIFY `home_slider_picture_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `inquiry_message`
--
ALTER TABLE `inquiry_message`
  MODIFY `inquiry_message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `ips_on_hold`
--
ALTER TABLE `ips_on_hold`
  MODIFY `ai` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `ledger`
--
ALTER TABLE `ledger`
  MODIFY `ledger_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15781;
--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `location_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `login_errors`
--
ALTER TABLE `login_errors`
  MODIFY `ai` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;
--
-- AUTO_INCREMENT for table `mail`
--
ALTER TABLE `mail`
  MODIFY `mail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT for table `meta`
--
ALTER TABLE `meta`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `news_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `news_group`
--
ALTER TABLE `news_group`
  MODIFY `news_group_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `news_pictures`
--
ALTER TABLE `news_pictures`
  MODIFY `news_picture_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1644;
--
-- AUTO_INCREMENT for table `physical_level`
--
ALTER TABLE `physical_level`
  MODIFY `physical_level_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `rate`
--
ALTER TABLE `rate`
  MODIFY `rate_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `rate_plan`
--
ALTER TABLE `rate_plan`
  MODIFY `rate_plan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `rate_price`
--
ALTER TABLE `rate_price`
  MODIFY `rate_price_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT for table `region`
--
ALTER TABLE `region`
  MODIFY `region_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;
--
-- AUTO_INCREMENT for table `service_level`
--
ALTER TABLE `service_level`
  MODIFY `service_level_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `style`
--
ALTER TABLE `style`
  MODIFY `style_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tax`
--
ALTER TABLE `tax`
  MODIFY `tax_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tax_plan`
--
ALTER TABLE `tax_plan`
  MODIFY `tax_plan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tax_type`
--
ALTER TABLE `tax_type`
  MODIFY `tax_type_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `template`
--
ALTER TABLE `template`
  MODIFY `template_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT for table `username_or_email_on_hold`
--
ALTER TABLE `username_or_email_on_hold`
  MODIFY `ai` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;