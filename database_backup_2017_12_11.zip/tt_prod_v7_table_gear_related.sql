
-- --------------------------------------------------------

--
-- Table structure for table `gear_related`
--

DROP TABLE IF EXISTS `gear_related`;
CREATE TABLE `gear_related` (
  `gear_id` int(11) NOT NULL,
  `gear_related_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `gear_related`
--

INSERT INTO `gear_related` (`gear_id`, `gear_related_id`) VALUES
(1, 3),
(3, 3),
(3, 4),
(4, 1),
(4, 3);
