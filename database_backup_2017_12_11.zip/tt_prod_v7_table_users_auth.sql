
-- --------------------------------------------------------

--
-- Table structure for table `users_auth`
--

DROP TABLE IF EXISTS `users_auth`;
CREATE TABLE `users_auth` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `username` varchar(25) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `auth_level` tinyint(3) UNSIGNED NOT NULL,
  `banned` enum('0','1') NOT NULL DEFAULT '0',
  `passwd` varchar(60) NOT NULL,
  `passwd_recovery_code` varchar(60) DEFAULT NULL,
  `passwd_recovery_date` datetime DEFAULT NULL,
  `passwd_modified_at` datetime DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `modified_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_auth`
--

INSERT INTO `users_auth` (`user_id`, `username`, `email`, `auth_level`, `banned`, `passwd`, `passwd_recovery_code`, `passwd_recovery_date`, `passwd_modified_at`, `last_login`, `created_at`, `modified_at`) VALUES
(110455817, 'GwenKrebs', 'gwenkrebs@gmail.com', 1, '0', '$2y$11$2qUSG5tjf/S.TftTUCavEuVoOjSpdfs2QIjVSR6HtbkP.UZ8cP2.i', NULL, NULL, NULL, '2017-01-15 18:18:45', '2017-01-15 18:18:29', '2017-01-15 18:18:45'),
(340062984, 'Terra', 'terra.laggner@gmail.com', 1, '0', '$2y$11$P0LukSEyYXU.bSZadrVW9OfZBtTuHFsrNbNdWMnP6p4PQujXD8wZq', NULL, NULL, NULL, NULL, '2017-07-05 15:43:34', '2017-07-05 15:43:34'),
(675264211, 'marty.foltz', 'foltzm3@gmail.com', 1, '0', '$2y$11$b9YQnsxY.ku4sJpfrO4LMurO5sibSm89zNmxxofpcy1OGq28Sg1R.', NULL, NULL, NULL, '2017-06-25 00:05:05', '2017-06-25 00:04:53', '2017-06-25 00:05:05'),
(1298669959, 'alfred.laggner', 'alfred.laggner@gmail.com', 9, '0', '$2y$11$Psig3vvNR3H748IbWauEZOjuhbieTirSXo5Cb0vgOpCwgSGued9MC', '$2y$11$LzK0sZext0fapBmhLh4M1OuAzs.k6hf9KZNii27TJHgqq9/56jgFy', '2017-01-15 02:04:06', NULL, '2017-01-16 19:16:06', '2017-01-14 19:15:26', '2017-01-16 19:16:06'),
(1475322983, 'motodancer1', 'motodancer1@gmail.com', 1, '0', '$2y$11$xbrgtHtOMSwVkElyqG/niOBb9hcuCANYsBrrywAjY6zZKiZSZJL56', NULL, NULL, NULL, '2017-07-07 03:07:18', '2017-07-04 19:00:48', '2017-07-07 03:07:18'),
(1601689362, 'celinaw', 'williamscelina12@gmail.com', 1, '0', '$2y$11$1oGYAcyKMkQew5yS.b/1v.G9yhIrnrDKnQLMdfevieuqAphvT8ILq', NULL, NULL, NULL, '2017-08-17 18:04:45', '2017-08-04 17:19:27', '2017-08-17 18:04:45'),
(1817101692, 'lisamanoogian', 'lmanoog@gmail.com', 1, '0', '$2y$11$Y0Scz/3OktGxWSvxbXckZeQHTOHp.Ph9Riu6CoFheerWd00bqip7O', NULL, NULL, NULL, '2017-09-26 18:26:58', '2017-01-15 18:18:10', '2017-09-26 18:26:58'),
(1957112167, 'janelles', 'janellerschank@gmail.com', 1, '0', '$2y$11$m3qsaX6u5iAcQwl4Zcu5yuDHaHMRkkPUhw97s2gPC2YHhxZ6mRlfa', NULL, NULL, NULL, '2017-07-22 01:58:29', '2017-07-13 16:16:13', '2017-07-22 01:58:29'),
(2353073138, 'zeritazonfrello', 'zzfirelillly@gmail.com', 1, '0', '$2y$11$QiLnhJyY2tdxcm58q1RiLOHMyKnUnMJis8RB.S5teAB1NfQ/llbuO', NULL, NULL, NULL, '2017-01-30 03:17:05', '2017-01-15 18:22:32', '2017-01-30 03:17:05'),
(2446419542, 'MastersZach', 'masters.s.zach@gmail.com', 1, '0', '$2y$11$UdqNPwKonNuNcFnWxvRnQ.IjDY/XsuDevuhFpv4MM97bOs2WaXbW2', NULL, NULL, NULL, '2017-09-20 16:58:27', '2017-07-31 16:40:50', '2017-09-20 16:58:27'),
(2461841510, 'Foxpettinotti', 'fpettinotti@gmail.com', 1, '0', '$2y$11$.AKL8tVzWzI9FWv8A8lyjuDBHOc2T8ZCnyVXHPsL8cJ2s1mF2P48y', NULL, NULL, NULL, '2017-01-16 05:13:26', '2017-01-15 18:17:45', '2017-01-16 05:13:26'),
(2636706811, 'Kevin Gilday', 'kgilday175@gmail.com', 1, '0', '$2y$11$azHNuBrtIksN575ioBehG.XtrzS4N/mYNQh9oRhjTmxF0OPxZs18O', NULL, NULL, NULL, '2017-08-11 22:00:32', '2017-01-15 18:19:21', '2017-08-11 22:00:32'),
(2843532195, 'Angelrodriguez', 'Rasdaddy831@gmail.com', 1, '0', '$2y$11$n.VDJuKkWFmxzYadiBcX6uWS4L7mTfll1ahh0qNavIo9saIXcIX9y', NULL, NULL, NULL, '2017-10-23 15:22:55', '2017-01-15 18:21:02', '2017-10-23 15:22:56'),
(3126085086, 'taylorkirsch', 'taylorjoykirsch@gmail.com', 1, '0', '$2y$11$wjmjDKG2N3aevLlYIBZ/f.J4fkl8en3E.VtCnOnVBuPr.WwX0qxDO', NULL, NULL, NULL, '2017-02-13 17:31:03', '2017-01-15 18:19:04', '2017-02-13 17:31:03'),
(3759188449, 'daniellaggner', 'daniel.laggner@gmail.com', 9, '0', '$2y$11$WHkF5eAf/sNYi5kfpDY2CeuzUJTnfhpvMovXUFUZ/a8xFa9YfgKHG', NULL, NULL, NULL, '2017-07-31 18:24:26', '2017-01-15 16:20:54', '2017-07-31 18:24:26'),
(3876230340, 'heidiheimerl', 'hkheimerl@gmail.com', 1, '0', '$2y$11$3lAoQadwPBuY.9gGEqkv8erOGJ1fqKM//dEX.0NKVOkgGwD9h887K', NULL, NULL, NULL, '2017-09-15 18:50:35', '2017-01-15 18:20:44', '2017-09-15 18:50:35');
