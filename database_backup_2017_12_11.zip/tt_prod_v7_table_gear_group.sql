
-- --------------------------------------------------------

--
-- Table structure for table `gear_group`
--

DROP TABLE IF EXISTS `gear_group`;
CREATE TABLE `gear_group` (
  `gear_group_id` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gear_group`
--

INSERT INTO `gear_group` (`gear_group_id`, `order`, `name`, `description`, `updated`, `updated_by`) VALUES
(1, 1, 'ropes', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>yep ropes</p>\n</body>\n</html>', '2014-01-04 22:16:38', 0),
(2, 3, 'carabiners', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n<p>carabiners</p>\n</body>\n</html>', '2014-01-04 22:20:09', 0),
(3, 2, 'quickdrwas', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n<head>\n<title>Untitled document</title>\n</head>\n<body>\n\n</body>\n</html>', '2014-01-04 22:19:39', 0);
