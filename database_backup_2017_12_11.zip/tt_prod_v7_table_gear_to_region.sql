
-- --------------------------------------------------------

--
-- Table structure for table `gear_to_region`
--

DROP TABLE IF EXISTS `gear_to_region`;
CREATE TABLE `gear_to_region` (
  `gear_id` int(11) NOT NULL,
  `region_id` int(11) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
