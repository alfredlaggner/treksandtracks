
-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

DROP TABLE IF EXISTS `equipment`;
CREATE TABLE `equipment` (
  `equipment_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `equipment` text COLLATE utf8_bin NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`equipment_id`, `name`, `equipment`, `updated`, `updated_by`) VALUES
(3, 'Easy', 'easy', '2012-02-08 00:28:41', 0),
(5, 'Not Easy', 'not easy', '2012-02-08 00:37:03', 0),
(6, 'Hard', 'hard but cool', '2012-02-08 00:36:44', 0),
(7, 'Demanding', 'demanding', '2012-02-08 00:37:15', 0),
(8, 'Expert', 'for experts only, but doable', '2012-02-08 00:37:26', 0);
