
-- --------------------------------------------------------

--
-- Table structure for table `rate_plan_to_rate`
--

DROP TABLE IF EXISTS `rate_plan_to_rate`;
CREATE TABLE `rate_plan_to_rate` (
  `rate_plan_id` int(11) NOT NULL,
  `rate_id` int(11) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
