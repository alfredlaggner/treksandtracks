
-- --------------------------------------------------------

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `account_id` int(11) NOT NULL,
  `created_on` date NOT NULL,
  `priority` int(11) NOT NULL,
  `account_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `account_short` varchar(10) COLLATE utf8_bin NOT NULL,
  `type` varchar(1) COLLATE utf8_bin NOT NULL,
  `first_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `last_name` varchar(255) COLLATE utf8_bin NOT NULL,
  `address1` varchar(255) COLLATE utf8_bin NOT NULL,
  `address2` varchar(255) COLLATE utf8_bin NOT NULL,
  `city` varchar(255) COLLATE utf8_bin NOT NULL,
  `zip` varchar(255) COLLATE utf8_bin NOT NULL,
  `state` varchar(255) COLLATE utf8_bin NOT NULL,
  `country` varchar(255) COLLATE utf8_bin NOT NULL,
  `employee_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`account_id`, `created_on`, `priority`, `account_name`, `account_short`, `type`, `first_name`, `last_name`, `address1`, `address2`, `city`, `zip`, `state`, `country`, `employee_id`) VALUES
(1, '2010-04-15', 1, 'Treks and Tracks', 'TAT', 'A', 'Andreas ', 'Kieslinger', 'a1', 'a2', 'ciry', '45455', 'Maine', 'United States of America', 5),
(2, '2012-05-17', 2, 'Shamanic Travel Adventures', 'STA', 'C', 'Jade', 'Wah\'oo', '', '', 'Sedona', '', 'Arizona', 'United States of America', 5),
(4, '2012-05-17', 3, 'Southern Trips', 'ST', 'H', 'Jordane', 'Michaels', '', '', 'Cochamo', '', 'California', 'Chile', 5);
